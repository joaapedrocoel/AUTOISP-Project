from fastapi import APIRouter, Depends
from backend.security.security_config import get_current_user

router = APIRouter()

@router.get("/dashboard")
def get_dashboard(current_user = Depends(get_current_user)):
    return {
        "clientes": 120,
        "dispositivos": 40,
        "onlines": 105,
        "ultimos_logins": ["10.0.0.12", "10.0.0.99"]
    }
