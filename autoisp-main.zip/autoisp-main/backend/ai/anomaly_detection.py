def detect_anomalies(metrics):
    # Análise básica de anomalias
    return [m for m in metrics if m['value'] > m['threshold']]
