def predict_failures(devices):
    # Exemplo fictício de lógica de previsão
    return [d for d in devices if "falha" in d['status']]
