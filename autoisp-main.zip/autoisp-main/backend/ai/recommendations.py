def recommend_actions(user):
    return ["Reinicie a OLT", "Verifique a VLAN 100", "Atualize firmware"]
