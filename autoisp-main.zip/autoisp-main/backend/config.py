DATABASE_URL = "mysql+pymysql://jdnetworking:32614300xD!@localhost/autoispdb"
SECRET_KEY = "d56cc7644630a457e4099fc43c4a363325aaadc48f72156ef3b361aab4963671"
