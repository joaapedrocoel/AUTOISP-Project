# Esquema do Banco de Dados AutoISP

## Tabelas

### clients
- id: INTEGER (PK)
- name: VARCHAR(100)
- created_at: DATETIME

...
