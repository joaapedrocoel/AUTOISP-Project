# Documentação da API AutoISP

## Endpoints

### Autenticação
- POST `/login`

### Clientes
- GET `/clients`

### Dispositivos
- GET `/devices`

### Monitoramento
- GET `/monitoring`

### Provisionamento
- POST `/provision`

...
