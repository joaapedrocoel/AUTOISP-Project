# Guia de Instalação do AutoISP

## Pré-requisitos
- Python 3.10
- Node.js 18+
- MySQL
- Docker e Docker Compose

## Passos

1. Clone o repositório
2. Configure o arquivo settings.json
3. Rode o script `autoisp_install.sh`
4. Acesse via `http://localhost:3000`

...
