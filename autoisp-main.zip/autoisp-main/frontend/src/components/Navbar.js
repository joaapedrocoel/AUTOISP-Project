import React from 'react';

function Navbar() {
  return (
    <nav>
      <h2>AutoISP</h2>
    </nav>
  );
}

export default Navbar;
