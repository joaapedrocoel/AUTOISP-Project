import React from 'react';

function Sidebar() {
  return (
    <aside>
      <ul>
        <li>Dashboard</li>
        <li>Clientes</li>
        <li>Dispositivos</li>
        <li>Sair</li>
      </ul>
    </aside>
  );
}

export default Sidebar;
