def test_permission():
    user_role = "admin"
    assert user_role in ["admin", "operator", "viewer"]
