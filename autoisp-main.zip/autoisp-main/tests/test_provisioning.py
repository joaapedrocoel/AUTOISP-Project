def test_provision():
    onu_serial = "ZNTS12345678"
    provisioned = True
    assert provisioned == True
