def test_health_check():
    response = {'message': 'Bem-vindo ao AutoISP'}
    assert response['message'] == 'Bem-vindo ao AutoISP'
